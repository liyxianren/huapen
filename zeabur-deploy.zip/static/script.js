// 全局变量
let chart;
let sensorData = [];
let previousData = {};
let currentQuery = null; // 当前查询状态

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeChart();
    loadData(); // 初始加载一次数据
    // 移除自动轮询，改为手动点击按钮更新

    // 刷新按钮事件
    document.getElementById('refreshBtn').addEventListener('click', loadData);

    // 查询按钮事件
    document.getElementById('queryByDateBtn').addEventListener('click', queryByDate);
    document.getElementById('queryByHourBtn').addEventListener('click', queryByHour);
    document.getElementById('resetQueryBtn').addEventListener('click', resetQuery);
});

// 初始化图表
function initializeChart() {
    const ctx = document.getElementById('sensorChart').getContext('2d');
    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: '湿度 (%)',
                    data: [],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: '温度 (°C)',
                    data: [],
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: '光照 (lux)',
                    data: [],
                    borderColor: '#f39c12',
                    backgroundColor: 'rgba(243, 156, 18, 0.1)',
                    tension: 0.4,
                    fill: true,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: false
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: '时间'
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: '湿度(%) / 温度(°C)'
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: '光照强度 (lux)'
                    },
                    grid: {
                        drawOnChartArea: false,
                    },
                }
            },
            animation: {
                duration: 750,
                easing: 'easeInOutQuart'
            }
        }
    });
}

// 加载数据
async function loadData() {
    // 如果处于查询状态，不自动刷新
    if (currentQuery) {
        return;
    }

    try {
        updateStatus('loading');

        const response = await fetch('/sensor-data');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        sensorData = result.data || [];

        updateCards();
        updateChart();
        updateTable();
        updateStatus('online');

    } catch (error) {
        console.error('Error loading data:', error);
        updateStatus('offline');
    }
}

// 更新状态指示器
function updateStatus(status) {
    const statusDot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');

    statusDot.className = 'status-dot';

    switch(status) {
        case 'online':
            statusDot.classList.add('online');
            statusText.textContent = '在线';
            break;
        case 'offline':
            statusDot.classList.add('offline');
            statusText.textContent = '离线';
            break;
        case 'loading':
            statusText.textContent = '加载中...';
            break;
    }
}

// 更新卡片数据
function updateCards() {
    if (sensorData.length === 0) return;

    const latestData = sensorData[sensorData.length - 1];

    // 更新数值
    document.getElementById('humidity').textContent = latestData.humidity;
    document.getElementById('temperature').textContent = latestData.temperature;
    document.getElementById('lightIntensity').textContent = latestData.light_intensity;

    // 更新统计信息
    document.getElementById('totalRecords').textContent = sensorData.length;
    document.getElementById('lastUpdate').textContent = formatTime(latestData.timestamp);

    // 更新趋势指示器
    updateTrends(latestData);

    previousData = latestData;
}

// 更新趋势指示器
function updateTrends(currentData) {
    if (!previousData.humidity) return;

    const trends = [
        { id: 'humidityTrend', current: currentData.humidity, previous: previousData.humidity },
        { id: 'temperatureTrend', current: currentData.temperature, previous: previousData.temperature },
        { id: 'lightTrend', current: currentData.light_intensity, previous: previousData.light_intensity }
    ];

    trends.forEach(trend => {
        const element = document.getElementById(trend.id);
        const diff = trend.current - trend.previous;

        if (diff > 0) {
            element.innerHTML = '↗';
            element.className = 'card-trend trend-up';
        } else if (diff < 0) {
            element.innerHTML = '↘';
            element.className = 'card-trend trend-down';
        } else {
            element.innerHTML = '→';
            element.className = 'card-trend trend-stable';
        }
    });
}

// 更新图表
function updateChart() {
    if (!chart || sensorData.length === 0) return;

    // 限制显示最近20个数据点
    const displayData = sensorData.slice(-20);

    chart.data.labels = displayData.map(item => formatTime(item.timestamp, true));
    chart.data.datasets[0].data = displayData.map(item => item.humidity);
    chart.data.datasets[1].data = displayData.map(item => item.temperature);
    chart.data.datasets[2].data = displayData.map(item => item.light_intensity);

    chart.update('none'); // 无动画更新以提高性能
}

// 更新表格
function updateTable() {
    const tableBody = document.getElementById('tableBody');
    tableBody.innerHTML = '';

    // 显示最近10条记录，倒序显示
    const recentData = sensorData.slice(-10).reverse();

    recentData.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${formatTime(item.timestamp)}</td>
            <td>${item.humidity}</td>
            <td>${item.temperature}</td>
            <td>${item.light_intensity}</td>
        `;
        tableBody.appendChild(row);
    });
}

// 格式化时间
function formatTime(timestamp, shortFormat = false) {
    const date = new Date(timestamp);

    if (shortFormat) {
        return date.toLocaleTimeString('zh-CN', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }

    return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

// 错误处理
window.addEventListener('error', function(event) {
    console.error('JavaScript Error:', event.error);
    updateStatus('offline');
});

// 网络状态监测
window.addEventListener('online', function() {
    updateStatus('online');
    loadData();
});

window.addEventListener('offline', function() {
    updateStatus('offline');
});

// 按日期查询数据
async function queryByDate() {
    const year = document.getElementById('queryYear').value;
    const month = document.getElementById('queryMonth').value;
    const day = document.getElementById('queryDay').value;

    if (!year || !month || !day) {
        alert('请输入完整的年月日信息');
        return;
    }

    try {
        updateQueryStatus('loading');

        // 使用通用API获取所有数据，然后在前端过滤
        const response = await fetch('/sensor-data');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        const allData = result.data || [];

        // 构建目标日期字符串 (YYYY-MM-DD)
        const targetDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;

        // 在前端过滤指定日期的数据
        const filteredData = allData.filter(item => {
            const itemDate = new Date(item.timestamp).toISOString().split('T')[0];
            return itemDate === targetDate;
        });

        sensorData = filteredData;

        currentQuery = {
            type: 'date',
            year: year,
            month: month,
            day: day
        };

        updateQueryResultInfo(`${year}年${month}月${day}日`, filteredData.length);
        updateCards();
        updateChart();
        updateTable();
        updateStatus('online');

        if (filteredData.length === 0) {
            alert(`没有找到 ${year}年${month}月${day}日 的数据`);
        }

    } catch (error) {
        console.error('Error querying data by date:', error);
        updateStatus('offline');
        updateQueryResultInfo('查询失败', 0);
    }
}

// 按小时查询数据
async function queryByHour() {
    const year = document.getElementById('queryYear').value;
    const month = document.getElementById('queryMonth').value;
    const day = document.getElementById('queryDay').value;
    const hour = document.getElementById('queryHour').value;

    if (!year || !month || !day || hour === '') {
        alert('请输入完整的年月日时信息');
        return;
    }

    try {
        updateQueryStatus('loading');

        // 使用通用API获取所有数据，然后在前端过滤
        const response = await fetch('/sensor-data');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        const allData = result.data || [];

        // 构建目标日期和小时字符串
        const targetDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        const targetHour = parseInt(hour);

        // 在前端过滤指定日期和小时的数据
        const filteredData = allData.filter(item => {
            const itemDateTime = new Date(item.timestamp);
            const itemDate = itemDateTime.toISOString().split('T')[0];
            const itemHour = itemDateTime.getHours();
            return itemDate === targetDate && itemHour === targetHour;
        });

        sensorData = filteredData;

        currentQuery = {
            type: 'hour',
            year: year,
            month: month,
            day: day,
            hour: hour
        };

        updateQueryResultInfo(`${year}年${month}月${day}日${hour}时`, filteredData.length);
        updateCards();
        updateChart();
        updateTable();
        updateStatus('online');

        if (filteredData.length === 0) {
            alert(`没有找到 ${year}年${month}月${day}日${hour}时 的数据`);
        }

    } catch (error) {
        console.error('Error querying data by hour:', error);
        updateStatus('offline');
        updateQueryResultInfo('查询失败', 0);
    }
}

// 重置查询，显示所有数据
async function resetQuery() {
    currentQuery = null;

    // 设置为当前日期
    const today = new Date();
    document.getElementById('queryYear').value = today.getFullYear();
    document.getElementById('queryMonth').value = today.getMonth() + 1;
    document.getElementById('queryDay').value = today.getDate();
    document.getElementById('queryHour').value = '';

    // 重新加载所有数据
    updateQueryResultInfo('显示所有数据', '');
    await loadData();
}

// 更新查询结果信息
function updateQueryResultInfo(queryText, count) {
    document.getElementById('queryResultText').textContent = queryText;
    document.getElementById('queryResultCount').textContent = count ? `(${count} 条记录)` : '';
}

// 更新查询状态
function updateQueryStatus(status) {
    const resultInfo = document.getElementById('queryResultInfo');

    switch(status) {
        case 'loading':
            document.getElementById('queryResultText').textContent = '查询中...';
            document.getElementById('queryResultCount').textContent = '';
            break;
    }
}

// 请求传感器数据更新
async function requestSensorUpdate() {
    const btn = document.getElementById('updateDataBtn');
    const originalText = btn.innerHTML;

    try {
        // 更新按钮状态
        btn.classList.add('updating');
        btn.innerHTML = '📡 发送指令中...';
        btn.disabled = true;

        // 发送更新请求到ESP8266
        const response = await fetch('/sensor-command', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                command: 'Dataup_0'
            })
        });

        const result = await response.json();

        if (result.status === 'success') {
            // 指令发送成功
            btn.innerHTML = '⏳ 等待数据更新...';

            // 等待一段时间让传感器读取新数据
            setTimeout(async () => {
                try {
                    // 刷新数据
                    await loadData();

                    btn.classList.remove('updating');
                    btn.innerHTML = '✅ 数据已更新';
                    btn.disabled = false;

                    // 3秒后恢复按钮状态
                    setTimeout(() => {
                        btn.innerHTML = originalText;
                    }, 3000);

                } catch (error) {
                    console.error('刷新数据失败:', error);
                    btn.classList.remove('updating');
                    btn.innerHTML = '❌ 刷新失败';
                    btn.disabled = false;

                    setTimeout(() => {
                        btn.innerHTML = originalText;
                    }, 3000);
                }
            }, 3000); // 等待3秒让传感器读取数据

        } else {
            throw new Error(result.message || '指令发送失败');
        }

    } catch (error) {
        console.error('请求传感器更新失败:', error);
        btn.classList.remove('updating');
        btn.innerHTML = '❌ 发送失败';
        btn.disabled = false;

        // 3秒后恢复按钮状态
        setTimeout(() => {
            btn.innerHTML = originalText;
        }, 3000);

        // 显示错误提示
        alert('无法发送更新指令，请检查ESP8266连接状态');
    }
}