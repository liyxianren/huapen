"""
Main entry point for Zeabur deployment
"""
from app_sqlite import app

if __name__ == '__main__':
    app.run()
